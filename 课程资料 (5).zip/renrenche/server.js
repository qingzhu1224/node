const koa=require('koa');
const static=require('koa-static');
const mysql=require('koa-mysql');
const route=require('koa-route');
const body=require('koa-better-body');
const ejs=require('koa-ejs');
const session=require('koa-session');
const common=require('./libs/common');

let db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170226'});

let server=new koa();
server.listen(5000);

//session相关的
{
  server.keys=[];
  for(let i=0;i<10000;i++){
    server.keys.push('KOA_SESS_'+Math.random());
  }
}
server.use(session(server));

//ejs相关的
ejs(server, {
  root: 'template/',
  layout: false,
  viewExt: 'ejs',
  cache: false,
  debug: true
});

//post数据
server.use(body());





//请求：
//1.接口
//2.后台管理
server.use(route.get('/admin/*', function *(ctx, next){
  if(!this.session['admin'] && this.url!='/admin/login'){
    this.redirect('/admin/login');
  }else{
    yield next;
  }
}));

server.use(route.get('/admin/', function* (){
  yield this.render('index');
}))
server.use(route.get('/admin/login', function *(){
  yield this.render('login', {});
}));
server.use(route.post('/admin/login', function *(){
  //this.request.fields=>{user: '用户名', pass: '密码'}
  let rows=yield db.query(`SELECT * FROM admin_table WHERE username='${this.request.fields['user']}'`);

  if(rows.length==0){
    this.body='没有这个用户';
  }else{
    if(rows[0].password==common.md5(this.request.fields['pass'])){
      this.session['admin']=true;
      this.redirect('/admin/');
    }else{
      this.body='密码错了';
    }
  }
}));

server.use(route.get('/admin/city', function *(){
  this.body='管理城市';
}));

//3.静态文件
server.use(static('public_static'));
