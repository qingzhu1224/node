function Person(name, age){
  this.name=name;
  this.age=age;
}

Person.prototype.showName=function (){
  console.log(this.name);
};
Person.prototype.showAge=function (){
  console.log(this.age);
};


function Worker(name, age, job){
  Person.call(this, name, age);

  this.job=job;
}

Worker.prototype=new Person();
Worker.prototype.constructor=Worker;
Worker.prototype.showJob=function (){
  console.log(this.job);
}

let p=new Person('blue', 18);
let w=new Worker('张三', 25, '唱歌');

//p.showName();
//p.showAge();

w.showName();
w.showAge();
w.showJob();
