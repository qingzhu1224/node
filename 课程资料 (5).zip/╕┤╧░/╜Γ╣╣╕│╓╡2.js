let {a, b}={a: 12, b: 5};

console.log(a,b);
