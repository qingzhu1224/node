const koa=require('koa');
const static=require('koa-static');

let server=new koa();
server.listen(5000);

server.use(static('www'));
