let oDate=new Date();

oDate.setDate(oDate.getDate()+5);

console.log(oDate);
