let [{a, b}, num, [user1, user2]]=[{a: 1, b: 2}, 55, [{user: 1, pass: 2}, {user: 2, pass: 3}]]

console.log(a, b, num, user1, user2);
