const express=require('express');
const static=require('express-static');

let server=express();
server.listen('5000');

server.use(static('www'));
