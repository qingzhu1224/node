const pug=require('pug');
const mysql=require('mysql');

const db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170223'});

db.query(`SELECT * FROM user_table`, (err, data)=>{
  if(err){
    console.log('数据库错了', err);
  }else{
    pug.renderFile('./template/1.pug', {pretty: true, arr: data}, (err, str)=>{
      if(err){
        console.log('错了', err);
      }else{
        console.log(str);
      }
    });
  }
});
