const http=require('http');
const fs=require('fs');
const urlLib=require('url');
const mysql=require('mysql');
const pug=require('pug');
const runner=require('yield-runner-blue');

const db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170223'});

let server=http.createServer((req, res)=>{
  let urlObj=urlLib.parse(req.url);
  let tempPathname='template'+urlObj.pathname+'.pug';

  runner(function* (){
    let stat=yield fsStat(tempPathname);
    let code=yield checkCache(stat);

    if(code==304){
      res.writeHeader(304);
      res.end();
    }else{
      yield setCacheHeader(stat);
      let data=yield database(`SELECT * FROM user_table`);
      let str=yield pubRender(tempPathname, {arr: data});

      res.write(str);
      res.end();
    }
  }).catch(err=>{
    res.writeHeader(500);
    res.write('server error');
    res.end();
  });

  function fsStat(filename){
    return new Promise((resolve, reject)=>{
      fs.stat(filename, (err, stat)=>{
        if(err)
          reject(err);
        else
          resolve(stat);
      });
    });
  }

  function checkCache(stat){
    return new Promise((resolve, reject)=>{
      if(
        req.headers['if-modified-since']
        &&
        (
          Math.floor(new Date(req.headers['if-modified-since']).getTime()/1000)>=
          Math.floor(stat.mtime.getTime()/1000)
        )
      ){
        resolve(304);
      }else{
        resolve(200);
      }
    });
  }

  function setCacheHeader(stat){
    return new Promise((resolve, reject)=>{
      res.setHeader('cache-control', 'private');
      res.setHeader('date', new Date().toUTCString());

      let oDate=new Date();
      oDate.setDate(oDate.getDate()+15);
      res.setHeader('expires', oDate.toUTCString());

      res.setHeader('last-modified', stat.mtime.toUTCString());

      resolve();
    });
  }

  function database(sql){
    return new Promise((resolve, reject)=>{
      db.query(sql, (err, data)=>{
        if(err){
          reject(err);
        }else{
          resolve(data);
        }
      });
    });
  }

  function pubRender(filename, data){
    data.pretty=true;

    return new Promise((resolve, reject)=>{
      pug.renderFile(filename, data, (err, data)=>{
        if(err)
          reject(err);
        else
          resolve(data);
      });
    });
  }
});
server.listen(5000);
