const http=require('http');
const fs=require('fs');
const urlLib=require('url');
const mysql=require('mysql');
const pug=require('pug');

const db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170223'});

let server=http.createServer((req, res)=>{
  let urlObj=urlLib.parse(req.url);
  let tempPathname='template'+urlObj.pathname+'.pug';

  fsStat(tempPathname).then(stat=>{
    checkCache(stat).then(code=>{
      if(304){
        res.writeHeader('304');
        res.write('not modified');
        res.end();
      }else{
        setCacheHeader(stat).then(()=>{
          database(`SELECT * FROM user_table`, data=>{
            pubRender(tempPathname, {arr: data}).then(data=>{
              res.write(data);
              res.end();
            }, err=>{
              res.writeHeader(500);
              res.write('render error');
              res.end();
            });
          }, err=>{
            res.writeHeader('500');
            res.write('database error');
            res.end();
          });
        });
      }
    });
  }, err=>{
    res.writeHeader('404');
    res.write('not found');
    res.end();
  });

  function fsStat(filename){
    return new Promise((resolve, reject)=>{
      fs.stat(filename, (err, stat)=>{
        if(err)
          reject(err);
        else
          resolve(stat);
      });
    });
  }

  function checkCache(stat){
    return new Promise((resolve, reject)=>{
      if(
        req.headers['if-modified-since']
        &&
        (
          Math.floor(new Date(req.headers['if-modified-since']).getTime()/1000)>=
          Math.floor(stat.mtime.getTime()/1000)
        )
      ){
        resolve(304);
      }else{
        resolve(200);
      }
    });
  }

  function setCacheHeader(stat){
    return new Promise((resolve, reject)=>{
      res.setHeader('cache-control', 'private');
      res.setHeader('date', new Date().toUTCString());

      let oDate=new Date();
      oDate.setDate(oDate.getDate()+15);
      res.setHeader('expires', oDate.toUTCString());

      res.setHeader('last-modified', stat.mtime.toUTCString());

      resolve();
    });
  }

  function database(sql){
    return new Promise((resolve, reject)=>{
      db.query(sql, (err, data)=>{
        if(err){
          reject(err);
        }else{
          resolve(data);
        }
      });
    });
  }

  function pubRender(filename, data){
    data.pretty=true;

    return new Promise((resolve, reject)=>{
      pug.renderFile(filename, data, (err, data)=>{
        if(err)
          reject(err);
        else
          resolve(data);
      });
    });
  }
});
server.listen(5000);
