let [a,b,c]=[1,2,3];

console.log(a,b,c);
