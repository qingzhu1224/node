let p1=new Promise((resolve, reject)=>{
  console.log('aaaa');

  setTimeout(()=>{
    resolve([1,2,3]);
  }, 2000);
});
let p2=new Promise((resolve, reject)=>{
  console.log('bbb');

  setTimeout(()=>{
    resolve(55);
  }, 2000);
});
let p3=new Promise((resolve, reject)=>{
  console.log('cccc');

  setTimeout(()=>{
    resolve({a: 12, b: 88});
  }, 2000);
});

Promise.all([p1, p2, p3]).then((result)=>{
  //result=>[结果1([1,2,3]), 结果2(55), 结果3({a: 12, b: 88})]
  let [arr, num, {a, b}]=result;

  console.log('成功了');
  console.log(arr, num, a, b);
}, ()=>{
  console.log('失败了');
});
