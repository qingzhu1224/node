const http=require('http');
const fs=require('fs');
const urlLib=require('url');

let server=http.createServer((req, res)=>{
  let urlObj=urlLib.parse(req.url);

  fs.stat('www'+urlObj.pathname, (err, stat)=>{
    if(err){
      res.writeHeader('404', 'mei le');
      res.write('404');
      res.end();
    }else{
      if(
        req.headers['if-modified-since']

        &&

        (
          Math.floor(new Date(req.headers['if-modified-since']).getTime()/1000)>=
          Math.floor(stat.mtime.getTime()/1000)
        )
      ){
        res.writeHeader(304, 'mei gai guo, yong ba');
        res.end();
      }else{
        //Cache-Control头
        res.setHeader('cache-control', 'private');

        //Date头
        res.setHeader('date', new Date().toUTCString());

        //Expires头
        let oDate=new Date();
        oDate.setDate(oDate.getDate()+15);

        res.setHeader('expires', oDate.toUTCString());

        //Last-Modified头
        res.setHeader('last-modified', stat.mtime.toUTCString());

        let rs=fs.createReadStream('www'+urlObj.pathname);

        rs.pipe(res);

        rs.on('error', err=>{
          res.writeHeader(404, 'mei zhao dao');
          res.write('Not Found');
          res.end();
        });
      }
    }
  });
});
server.listen(5000);
