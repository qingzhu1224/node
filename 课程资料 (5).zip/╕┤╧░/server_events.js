const http=require('http');
const fs=require('fs');
const urlLib=require('url');
const mysql=require('mysql');
const pug=require('pug');
const EventEmitter=require('events').EventEmitter;

const db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170223'});

let server=http.createServer((req, res)=>{
  const ev=new EventEmitter();

  let urlObj=urlLib.parse(req.url);
  let tempPathname='template'+urlObj.pathname+'.pug';

  ev.on('fs-stat', ()=>{
    fs.stat(tempPathname, (err, stat)=>{
      if(err){
        res.writeHeader('404', 'mei le');
        res.write('404');
        res.end();
      }else{
        ev.emit('cache', stat);
      }
    });
  });
  ev.on('cache', (stat)=>{
    if(
      req.headers['if-modified-since']
      &&
      (
        Math.floor(new Date(req.headers['if-modified-since']).getTime()/1000)>=
        Math.floor(stat.mtime.getTime()/1000)
      )
    ){
      res.writeHeader(304, 'mei gai guo, yong ba');
      res.end();
    }else{
      ev.emit('set-cache-header', stat);
    }
  });
  ev.on('set-cache-header', (stat)=>{
    //Cache-Control头
    res.setHeader('cache-control', 'private');

    //Date头
    res.setHeader('date', new Date().toUTCString());

    //Expires头
    let oDate=new Date();
    oDate.setDate(oDate.getDate()+15);

    res.setHeader('expires', oDate.toUTCString());

    //Last-Modified头
    res.setHeader('last-modified', stat.mtime.toUTCString());

    ev.emit('database');
  })
  ev.on('database', ()=>{
    db.query(`SELECT * FROM user_table`, (err, data)=>{
      if(err){
        res.writeHeader(500, 'Internal Server Error');
        res.write('Internal Server Error');
        res.end();
      }else{
        ev.emit('pug-render', data);
      }
    });
  });
  ev.on('pug-render', (data)=>{
    pug.renderFile(tempPathname, {pretty: true, arr: data}, (err, data)=>{
      if(err){
        res.writeHeader(500, 'Internal Server Error');
        res.write('Internal Server Error');
        res.end();
      }else{
        res.write(data);
        res.end();
      }
    });
  });

  ev.emit('fs-stat');
});
server.listen(5000);
