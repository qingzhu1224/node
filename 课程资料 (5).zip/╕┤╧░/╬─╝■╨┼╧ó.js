const fs=require('fs');

fs.stat('www/1.html', (err, stat)=>{
  console.log(stat);
});
