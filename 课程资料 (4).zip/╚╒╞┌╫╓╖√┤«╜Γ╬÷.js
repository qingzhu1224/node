let str='Sun, 19 Feb 2017 00:15:42 GMT'

let oDate=new Date(str);

console.log(oDate.getHours()+':'+oDate.getMinutes()+':'+oDate.getSeconds());
