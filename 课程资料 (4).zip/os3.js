const os=require('os');

let cpus=os.cpus();

console.log(cpus.length);
