const cluster=require('cluster');
const process=require('process');
const fs=require('fs');

let start=0;

if(cluster.isMaster){
  let obj=cluster.fork();

  setInterval(()=>{
    fs.stat(__filename, (err, stat)=>{
      if(err)return;

      let now=stat.mtime.getTime();
      if(start==0){
        start=now;
      }

      if(start!=now){
        start=now;

        obj.on('exit', ()=>{
          console.log('死完了，创建了');
          obj=cluster.fork();
        });
        obj.kill();
      }
    });
  }, 500);
}else{
  const http=require('http');

  http.createServer((req, res)=>{
    res.write('3333');
    res.end();
  }).listen(5000);
}
