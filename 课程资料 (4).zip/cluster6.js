const cluster=require('cluster');
const os=require('os');
const process=require('process');

if(cluster.isMaster){
  let aChild=[];
  for(let i=0;i<os.cpus().length;i++){
    let obj=cluster.fork();

    (function (obj){
      obj.on('exit', (code)=>{
        console.log('子进程退出', code);

        //删掉老的
        for(let i=0;i<aChild.length;i++){
          if(aChild[i]==obj){
            aChild.splice(i, 1);
          }
        }

        //弄个新的
        let newObj=cluster.fork();
        aChild.push(newObj);
      });
    })(obj);

    aChild.push(obj);
  }

  console.log('主进程');
}else{
  const http=require('http');

  http.createServer((req, res)=>{
    if(Math.random()<0.1){
      oDiv.style.display='block';
    }
    res.write('abc');
    res.end();
    console.log(process.pid+'干活了');
  }).listen(5000);
  console.log('子进程');
}
