const assert=require('assert');

function sum(num1, num2){
  assert(typeof num1=='number', 'num1参数必须是数字');
  assert(typeof num2=='number', 'num2参数必须是数字');

  return num1+num2;
}

console.log(sum('abc', 5));
