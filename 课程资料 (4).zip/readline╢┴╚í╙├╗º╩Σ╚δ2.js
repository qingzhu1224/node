const readline=require('readline');
const process=require('process');

let obj=readline.createInterface({
  input: process.stdin
});

console.log('请输入第1个数字:');
obj.once('line', (str)=>{
  let num1=parseInt(str);

  console.log('请输入第2个数字:');
  obj.once('line', (str)=>{
    let num2=parseInt(str);

    console.log('相加：'+(num1+num2));
  });
});
