const cluster=require('cluster');

console.log(cluster);
