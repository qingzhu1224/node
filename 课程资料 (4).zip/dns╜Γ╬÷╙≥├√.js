const dns=require('dns');

dns.resolve('facebook.com', (err, data)=>{
  console.log(err);
  console.log(data);
});
