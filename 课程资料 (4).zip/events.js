const Event=require('events').EventEmitter;

let ev=new Event();

//监听事件(收)
ev.on('aaa', (num, json, str)=>{
  console.log('收到事件了：', num, json, str);
});
//ev.removeListener();

//ev.once()


//派发事件(发)
ev.emit('aaa', 12, {a: 12, b: 5}, 'abc');
ev.emit('aaa', 12, {a: 12, b: 5}, 'abc');
ev.emit('aaa', 12, {a: 12, b: 5}, 'abc');
ev.emit('aaa', 12, {a: 12, b: 5}, 'abc');
ev.emit('aaa', 12, {a: 12, b: 5}, 'abc');
