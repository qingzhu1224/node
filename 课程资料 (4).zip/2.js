const http=require('http');
const urlLib=require('url');
const fs=require('fs');
const zlib=require('zlib');

http.createServer((req, res)=>{
  let obj=urlLib.parse(req.url);
  let rs=fs.createReadStream('www'+obj.pathname);

  rs.pipe(res);

  rs.on('error', err=>{
    res.writeHeader(404);
    res.write('not found');
    res.end();
  });
}).listen(5000);
