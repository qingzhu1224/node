const readline=require('readline');
const process=require('process');

let obj=readline.createInterface({
  input: process.stdin
});

obj.once('line', (str)=>{
  console.log(str);
});
