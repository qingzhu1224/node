const os=require('os');

let info=os.userInfo();

console.log(info);
