const cluster=require('cluster');
const os=require('os');
const process=require('process');

if(cluster.isMaster){
  let aChild=[];
  for(let i=0;i<os.cpus().length;i++){
    let obj=cluster.fork();

    aChild.push(obj);
  }

  console.log('主进程');
}else{
  const http=require('http');

  http.createServer((req, res)=>{

    res.write('abc');
    res.end();
    console.log(process.pid+'干活了');

    for(let i=0;i<100000;i++){
      for(let j=0;j<10000;j++){
        let a=12;
      }
    }
  }).listen(5000);


  console.log('子进程');
}
