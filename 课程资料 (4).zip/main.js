const http=require('http');
const urlLib=require('url');
const fs=require('fs');
const zlib=require('zlib');

http.createServer((req, res)=>{
  res.write('zxcvzxcvzxv');
  res.end();
}).listen(5000);
