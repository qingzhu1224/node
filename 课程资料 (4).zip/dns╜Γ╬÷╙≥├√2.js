const dns=require('dns');

dns.reverse('74.117.178.36', (err, data)=>{
  console.log(err);
  console.log(data);
});
