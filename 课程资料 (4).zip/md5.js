const crypto=require('crypto');

let obj=crypto.createHash('md5');

//obj.update('abcdef');

obj.update('a');
obj.update('bc');
obj.update('def');

console.log(obj.digest('hex'));


/*
hex-16
deg-10
oct-8
bin-2
*/
