const http=require('http');
const urlLib=require('url');
const fs=require('fs');
const zlib=require('zlib');

http.createServer((req, res)=>{
  let obj=urlLib.parse(req.url);
  let rs=fs.createReadStream('www'+obj.pathname);
  let gz=zlib.createGzip();

  fs.stat('www'+obj.pathname, (err, stat)=>{
    if(err){
      res.writeHeader(404);
      res.write('not found');
      res.end();
    }else{

      if(
        Math.floor(new Date(req.headers['if-modified-since']).getTime()/1000)
        <
        Math.floor(stat.mtime.getTime()/1000)
      ){
        console.log('200');
        let now=new Date();

        let expires=new Date();
        expires.setDate(expires.getDate()+1);

        res.setHeader('cache-control', 'private');
        res.setHeader('date', now.toUTCString());
        res.setHeader('expires', expires.toUTCString());
        res.setHeader('last-modified', stat.mtime.toUTCString());

        res.setHeader('content-encoding', 'gzip');

        rs.pipe(gz).pipe(res);

        rs.on('error', err=>{
          res.writeHeader(404);
          res.write('not found');
          res.end();
        });
      }else{
        console.log('304');
        res.writeHeader('304');
        res.write('not modified');
        res.end();
      }
    }
  });
}).listen(5000);
