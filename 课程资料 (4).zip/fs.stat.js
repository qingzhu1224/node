const fs=require('fs');

fs.stat('www/2.txt', (err, stat)=>{
  console.log(err);
  console.log(stat);
});
