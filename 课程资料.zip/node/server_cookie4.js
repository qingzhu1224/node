const http=require('http');

http.createServer((req, res)=>{
  res.setHeader('set-cookie', 'a=12');
  res.setHeader('set-cookie', 'b=5');
  res.setHeader('set-cookie', 'user=blue');
  res.setHeader('set-cookie', 'age=18');
  res.writeHeader(200, 'OK');
  res.write('aaa');
  res.end();



}).listen(8080);
