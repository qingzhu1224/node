
var b=new Buffer("12-aa-bbc");
var result=[];
var arr=[];

for(var i=0;i<b.length;i++){
  if(b[i]!='-'.charCodeAt(0)){
    arr.push(b[i]);
  }else{
    result.push(new Buffer(arr));
    arr=[];
  }
}

if(arr.length!=0){
  result.push(new Buffer(arr));
}

console.log(result);
