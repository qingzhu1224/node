const Events=require('events').EventEmitter;

var ev=new Events();

//1.接收on
ev.on('error', (ev)=>{
  console.log(ev);
});




//......

ev.emit('not found');
