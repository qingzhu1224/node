const http=require('http');
const fs=require('fs');

//http.createServer(function (){}).listen(8080);
http.createServer((req, res)=>{
  //req.url -> '/a.html'
  //fs.readFile('./www/a.html')

  fs.readFile('./www'+req.url, (err, data)=>{
    if(err){
      res.writeHeader(404);
      res.write('Not Found');
    }else{
      res.writeHeader(200);
      res.write(data);
    }

    res.end();
  });
}).listen(8080);
