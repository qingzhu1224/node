const http=require('http');
const fs=require('fs');
const zlib=require('zlib');

http.createServer((req, res)=>{
  var gz=zlib.createGzip();
  var rs=fs.createReadStream('./www'+req.url);

  res.setHeader('content-encoding', 'gzip');

  rs.pipe(gz);
  gz.pipe(res);
  rs.on('error', function (err){
    console.log('读取出错');
  });
}).listen(8080);
