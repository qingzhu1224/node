const http=require('http');

http.createServer((req, res)=>{
  var oDate=new Date();
  oDate.setDate(oDate.getDate()+365);

  /*res.setHeader(
    'set-cookie',
    "a=12; expires="+oDate.toGMTString()
  );*/
  res.writeHeader(200, 'OK');
  res.write('aaa');
  res.end();



}).listen(8080);
