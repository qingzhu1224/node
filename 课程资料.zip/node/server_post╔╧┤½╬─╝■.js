const http=require('http');
const fs=require('fs');
const urlLib=require('url');
const querystring=require('querystring');
const binary=require('./libs/binary');

http.createServer((req, res)=>{
  var arr=[];
  req.on('data', (data)=>{
    arr.push(data);
  });
  req.on('end', ()=>{
    var b=Buffer.concat(arr);

    //解析b
    //1.用"分隔符"切分
    var arr1=req.headers['content-type'].split('; ');
    var arr2=arr1[1].split('=');
    var boundary=new Buffer('--'+arr2[1]);

    var _arr1=binary.binarySplit(b, boundary);
    _arr1.pop();
    _arr1.shift();

    //2.
    for(var i=0;i<_arr1.length;i++){
      _arr1[i]=_arr1[i].slice(2, _arr1[i].length-2);
    }

    //3.
    for(var i=0;i<_arr1.length;i++){
      var _arr2=binary.binarySplit(_arr1[i], new Buffer('\r\n\r\n'), 1);

      //_arr2[0]    文件信息
      //_arr2[1]    文件内容

      fs.writeFile('./www/upload/'+Math.random()+'.png', _arr2[1]);
    }
  });
}).listen(8080);
