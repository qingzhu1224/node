var oDate=new Date();

oDate.setDate(oDate.getDate()+30);

console.log(oDate.toGMTString());
