const fs=require('fs');

fs.readFile('a.txt', function (err, data){
  if(err){
    console.log('错了');
  }else{
    console.log(data.toString('utf-8'));
  }
});
