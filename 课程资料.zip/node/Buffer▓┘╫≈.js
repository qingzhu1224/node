
var b=new Buffer("12-aa-bbc");

//b.slice   substring

var b2=b.slice(0, 2);

console.log(b2.toString());
