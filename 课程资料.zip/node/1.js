const http=require('http');

var server=http.createServer(function (req, res){
  //console.log('有人来了');
  //req    接收请求
  //res    发送响应

  console.log(req.url);

  res.write("asdfasdf");
  res.end();
});

server.listen(8080);
