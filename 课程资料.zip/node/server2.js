const http=require('http');
const fs=require('fs');
const urlLib=require('url');
const querystring=require('querystring');

http.createServer((req, res)=>{
  var arr=[];
  req.on('data', (data)=>{
    arr.push(data);
  });
  req.on('end', ()=>{
    var b=Buffer.concat(arr);
    var str=b.toString();

    //GET
    var obj=urlLib.parse(req.url, true);
    var url=obj.pathname;
    var get=obj.query;

    //POST
    var post=querystring.parse(str);

    console.log(url, get, post);
  });
}).listen(8080);
