var b=new Buffer("12=-aa=-bbc");
var boundry=new Buffer('=-');

var result=[];
var s=0;

for(var i=0;i<b.length;i++){
  var found=true;
  for(var j=0;j<boundry.length;j++){
    if(b[i+j]!=boundry[j]){
      found=false;
      break;
    }
  }

  if(found==true){
    result.push(b.slice(s, i));
    s=i+boundry.length;
  }
}

result.push(b.slice(s));

console.log(result);
