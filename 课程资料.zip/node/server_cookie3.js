const http=require('http');

http.createServer((req, res)=>{
  res.setHeader('a', '12');
  res.setHeader('server', 'MNS');
  res.setHeader('x-application', 'v1.2.3');
  res.writeHeader(200, 'OK');
  res.write('aaa');
  res.end();



}).listen(8080);
