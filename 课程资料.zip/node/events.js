const Events=require('events').EventEmitter;

var ev=new Events();

//1.接收on
ev.on('data', (a)=>{
  console.log(a);
});

//2.发送emit
ev.emit('data', 12);
