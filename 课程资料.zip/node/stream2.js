const fs=require('fs');

var rs=fs.createReadStream('node.zip');
var ws=fs.createWriteStream('node2.zip');

rs.pipe(ws);
