console.log(49=='1'.charCodeAt(0));
