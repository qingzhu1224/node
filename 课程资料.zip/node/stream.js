const fs=require('fs');

fs.readFile('node.zip', (err, data)=>{
  if(err)
    console.log('有错');
  else{
    fs.writeFile('node2.zip', data, (err)=>{
      if(err)
        console.log('有错');
      else
        console.log('完成')
    });
  }
});
