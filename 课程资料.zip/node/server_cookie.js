const http=require('http');

http.createServer((req, res)=>{
  var cookies={};

  if(req.headers['cookie']){
    //"a=12; b=5; name=blue; gender=male"
    var arr=req.headers['cookie'].split('; ');

    for(var i=0;i<arr.length;i++){
      var arr2=arr[i].split('=');
      //arr2[0]   名字：a, b, name, ...
      //arr2[1]   值：12, 5, blue, ...

      cookies[arr2[0]]=arr2[1];
    }
  }
  console.log(cookies);

  res.write('aaa');
  res.end();
}).listen(8080);
