const http=require('http');
const querystring=require('querystring');

http.createServer((req, res)=>{
  var str='';
  req.on('data', (data)=>{
    str+=data;
  });
  req.on('end', ()=>{
    var post=querystring.parse(str);

    console.log(post);
  });
}).listen(8080);
