const http=require('http');
const cookieLib=require('./libs/cookie');

var sessions={
  //sess_id: {session_data}
  //sess_id: {...}
};

http.createServer((req, res)=>{
  var cookies=cookieLib.getCookie(req);
  if(!cookies['sess_id']){
    cookieLib.setCookie(res, [
      {sess_id: 'zns_'+Math.random()}
    ]);
  }

  //session问题
  var sess_id=cookies['sess_id'];

  if(!sessions[sess_id]){
    sessions[sess_id]={};
  }

  if(!sessions[sess_id].count){
    sessions[sess_id].count=1;
  }else{
    sessions[sess_id].count++;
  }

  console.log('第'+sessions[sess_id].count+'次访问');

  res.writeHeader(200, 'OK');
  res.write('aaa');
  res.end();



}).listen(8080);
