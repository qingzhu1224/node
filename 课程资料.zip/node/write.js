const fs=require('fs');

//文件名, 内容, 回调
fs.writeFile('b.txt', "sdfaswer", (err)=>{
  if(err)
    console.log('有错');
  else
    console.log('成功');
});
