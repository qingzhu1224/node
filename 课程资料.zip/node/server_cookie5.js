const http=require('http');

http.createServer((req, res)=>{
  res.setHeader(
    'set-cookie',
    "a=12; path=/qq"
  );
  res.writeHeader(200, 'OK');
  res.write('aaa');
  res.end();



}).listen(8080);
