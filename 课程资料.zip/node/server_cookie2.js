const http=require('http');

http.createServer((req, res)=>{
  res.writeHeader(200, 'good');
  res.write('aaa');
  res.end();


}).listen(8080);
