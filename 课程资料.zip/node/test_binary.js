const binary=require('./libs/binary');

const buffer=new Buffer("12-=-*sdfd-=-*54654trt-=-*5645645");
const spliter=new Buffer('-=-*');

var arr=binary.binarySplit(buffer, spliter, 2);

for(var i=0;i<arr.length;i++){
  console.log(arr[i].toString());
}
