const fs=require('fs');
const zlib=require('zlib');

var gz=zlib.createGzip();

var rs=fs.createReadStream('abc.txt');
var ws=fs.createWriteStream('abc.txt.gz');

rs.pipe(gz);
gz.pipe(ws);
