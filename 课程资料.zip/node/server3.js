const http=require('http');
const fs=require('fs');
const urlLib=require('url');
const querystring=require('querystring');

http.createServer((req, res)=>{
  var arr=[];
  req.on('data', (data)=>{
    arr.push(data);
  });
  req.on('end', ()=>{
    var b=Buffer.concat(arr);

    console.log(b.toString());
  });
}).listen(8080);
