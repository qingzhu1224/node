const http=require('http');
const cookieLib=require('./libs/cookie');

http.createServer((req, res)=>{
  var cookies=cookieLib.getCookie(req);

  cookieLib.setCookie(res, [
    {user: 'blue', path: '/'},
    {age: 18, maxage: 365*24*3600},
    {gender: 'male'}
  ]);

  res.writeHeader(200, 'OK');
  res.write('aaa');
  res.end();



}).listen(8080);
