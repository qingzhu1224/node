const http=require('http');
const fs=require('fs');

http.createServer((req, res)=>{
  var rs=fs.createReadStream('./www'+req.url);

  rs.pipe(res);
  rs.on('error', function (err){
    console.log('读取出错');
  });
}).listen(8080);
