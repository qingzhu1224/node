const http=require('http');

http.createServer((req, res)=>{
  if(req.url=='/'){
    res.setHeader('location', 'http://www.zhinengshe.com/');
    res.writeHeader(302);
  }

  res.end();
}).listen(8080);
