const Events=require('events').EventEmitter;

var ev=new Events();

//1.接收on
ev.once('data', (a)=>{
  console.log(a);
});

ev.emit('data', 12);
ev.emit('data', 5);
ev.emit('data', 6);
