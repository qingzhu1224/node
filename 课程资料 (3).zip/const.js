const a=12;
const a=5;
