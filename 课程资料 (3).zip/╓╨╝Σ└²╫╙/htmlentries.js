var json={
  '&nbsp;': ' ',
  '&lt;': '<',
  '&gt;': '>',
  '&copy;': '®',
};

//&nbsp;
//&lt;
//&gt;
//&copy;

var str="12&lt;5是错的";

var str2=str.replace(/&[a-z]{2,6};/g, (s)=>{
  return json[s]||'';
});
console.log(str, str2);
