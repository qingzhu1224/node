const urlLib=require('url');

var url='https://detail.tmall.com/item.htm?spm=a220m.1000858.1000725.1.Q1o47D&id=42946795296&areaId=110100&user_id=1583804544&cat_id=2&is_b=1&rn=67cb01f36882d176b12bcb9fd6824d5c';

var res=urlLib.parse(url);

console.log(res);
