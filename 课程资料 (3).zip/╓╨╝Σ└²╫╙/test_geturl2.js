const getUrl=require('./lib/get-url');
const gbk=require('gbk');

getUrl('http://news.sina.com.cn/c/nd/2017-01-15/doc-ifxzqnim4448741.shtml').then((b)=>{
  console.log(b.toString());
}, (err)=>{
  console.log('获取失败', err);
});
