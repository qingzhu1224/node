const jsdom=require('jsdom').jsdom;
const fs=require('fs');

var document=jsdom(fs.readFileSync('./tmp_html/sina.html'));

var title=document.getElementById('artibodyTitle').innerHTML;

console.log(title);
