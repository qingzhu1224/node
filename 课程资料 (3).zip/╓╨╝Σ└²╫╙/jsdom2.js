const jsdom=require('jsdom').jsdom;
const fs=require('fs');

var document=jsdom(fs.readFileSync('./tmp_html/sina.html'));

var oTime=document.querySelector('#page-info .time-source');
oTime.removeChild(oTime.children[0]);

var time=oTime.innerHTML;

console.log(time);
