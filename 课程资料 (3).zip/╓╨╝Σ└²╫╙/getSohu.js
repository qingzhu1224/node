//http://news.sohu.com/20170115/n478753989.shtml

const http=require('http');
const gbk=require('gbk');

//createRequest(请求参数, 回调)
const req=http.request({
  //protocol
  host: 'news.sohu.com',
  path: '/20170115/n478753989.shtml'
}, (res)=>{   //回调：不代表请求完成，整个回调函数就是请求的代码
  var arr=[];
  res.on('data', (data)=>{
    arr.push(data);
  });
  res.on('end', ()=>{
    var b=Buffer.concat(arr);

    console.log('结果');
    console.log(gbk.toString('utf-8', b));
  });

  console.log('回调了');
});

req.on('error', (err)=>{
  console.error('出错了', err);
});

//req.write();
req.end();
