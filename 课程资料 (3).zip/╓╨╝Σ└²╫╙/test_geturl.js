const getUrl=require('./lib/get-url');
const gbk=require('gbk');

getUrl('http://www.mi.com/kettle/').then((b)=>{
  console.log(b.toString());
}, (err)=>{
  console.log('获取失败', err);
});
