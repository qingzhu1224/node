const getUrl=require('./lib/get-url');
const parser=require('./parser/sina-news-parser');
const mysql=require('mysql');

var db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170115'});

getUrl('http://news.sina.com.cn/c/nd/2017-01-15/doc-ifxzqnim4448741.shtml').then((b)=>{
  var news_data=parser(b.toString());

  //console.log(news_data);
  var sql=`INSERT INTO sina_news_table (title, time, content, keyword) VALUES('${news_data.title}', '${news_data.time}', '${news_data.content}', '${news_data.keyword}')`;

  db.query(sql, (err, data)=>{
    if(err){
      console.log('数据库插入失败');
      console.error(err);
    }else{
      //console.log('请求成功');
      //console.log(data);
      console.log('[成功]', news_data.title);
    }
  });
}, (err)=>{
  console.log('获取失败', err);
});
