function stripslashes(str){
  return str.replace(/'/g, '\\\'').replace(/"/g, '\\\"').replace(/`/g, '\\\`');
}

var str='好啊""sss3242`\'dsg好';

console.log(str,'\n',stripslashes(str));
