const urlLib=require('url');
const gbk=require('gbk');

function get(url){
  var res=urlLib.parse(url);

  return new Promise((resolve, reject)=>{
    var mod=null;
    if(res.protocol=='http:'){
      mod=require('http');
    }else{
      mod=require('https');
    }
    const req=mod.request({
      host: res.host,
      path: res.path,
      port: res.port
    }, (res)=>{
      if(res.statusCode>=200 && res.statusCode<300){
        var arr=[];
        res.on('data', (data)=>{
          arr.push(data);
        });
        res.on('end', ()=>{
          var b=Buffer.concat(arr);

          resolve(b);
        });
      }else{    //错误
        if(res.statusCode==301 || res.statusCode==302){
          console.log('重定向了');
          console.log(res.headers);
        }else{
          reject(res.statusCode);
        }
      }
    });

    req.on('error', (err)=>{
      reject(err);
    });

    //req.write();
    req.end();
  });
}

//天猫
get('https://detail.tmall.com/item.htm?spm=a220m.1000858.1000725.1.Q1o47D&id=42946795296&areaId=110100&user_id=1583804544&cat_id=2&is_b=1&rn=67cb01f36882d176b12bcb9fd6824d5c').then((b)=>{
  console.log(gbk.toString('utf-8', b));
}, (err)=>{
  console.error(err);
});

/*
//苏宁
get('http://product.suning.com/0070086858/105452499.html').then((b)=>{
  console.log(b.toString());
}, (err)=>{
  console.error(err);
});
*/
