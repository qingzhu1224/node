const getUrl=require('./lib/get-url');
const gbk=require('gbk');

getUrl('http://news.sina.com.cn/c/nd/2017-01-15/doc-ifxzqnim4448741.shtml').then((b)=>{
  var str=b.toString();

  var title=str.match(/<h1 id="artibodyTitle" cid="\d+" docid="\w+">[^<]+<\/h1>/)[0];
  title=title.replace(/<[^<]+>/g, '');

  console.log(title);
}, (err)=>{
  console.log('获取失败', err);
});
