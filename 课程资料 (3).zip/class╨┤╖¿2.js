class Person{
  constructor(name, age){
    this.name=name;
    this.age=age;
  }
  showName(){
    console.log(this.name);
  }
  showAge(){
    console.log(this.age);
  }
}

//---------------------------------------

class Worker extends Person{
  constructor(name, age, job){
    super(name, age);       //super-超类(父类)

    this.job=job;
  }

  showJob(){
    console.log(this.job);
  }
}

var p=new Person('blue', 18);

p.showName();
p.showAge();


var w=new Worker('张三', 25, '销售');

w.showName();
w.showAge();
w.showJob();
