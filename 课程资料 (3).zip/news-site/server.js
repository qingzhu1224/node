const server=require('koa')();
const static=require('koa-static');
const route=require('koa-route');
const mysql=require('koa-mysql');

const db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170115'});

const PAGE_SIZE=10;

server.listen(8080);

///getPageList?page=1
server.use(route.get('/getPageList', function *(){
  var page=this.query.page||1;

  var sql=`SELECT ID,title,time FROM sina_news_table LIMIT ${(page-1)*PAGE_SIZE},${PAGE_SIZE}`;

  var data=yield db.query(sql);

  this.body=data;
}));

///getPageCount
server.use(route.get('/getPageCount', function *(){
  var data=yield db.query(`SELECT COUNT(*) AS c FROM sina_news_table`);

  this.body={count: Math.ceil(data[0].c/PAGE_SIZE)};
}));

///getNews?id=
server.use(route.get('/getNews', function *(){
  var data=yield db.query(`SELECT * FROM sina_news_table WHERE ID=${this.query.id}`);

  if(data.length==0){
    this.status=404;
    this.body='no this news';
  }else{
    this.body=data[0];
  }
}));

///searchKey?key=xxx
server.use(route.get('/searchKey', function *(){
  this.body=yield db.query(`SELECT ID,title,time FROM sina_news_table WHERE keyword LIKE '%,${this.query.key},%'`);
}));

server.use(static('./static/'));
