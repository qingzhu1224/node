var arr1=[12, 5, 8];

var arr2=arr1.map((n)=>{
  return n+3;
});

console.log(arr2);    //15, 8, 11
