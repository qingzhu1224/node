const getSinaNews=require('./lib/get-sina-news');

getSinaNews('http://news.sina.com.cn/c/2017-01-14/doc-ifxzqnva3560542.shtml').then((newsData)=>{
  console.log('采集成功');
  console.log(newsData);
}, (err)=>{
  console.log('新闻采集失败', err);
});
