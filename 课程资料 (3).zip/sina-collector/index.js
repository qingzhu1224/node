const getSinaNewsPage=require('./lib/get-sina-news-page');

var page=1;

_next();
function _next(){
  getSinaNewsPage(page).then(()=>{
    page++;

    _next();
  }, (err)=>{
    console.error('失败了', err);
  });

}
