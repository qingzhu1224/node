const getUrl=require('./lib/get-url');
const getSinaNews=require('./lib/get-sina-news');

getUrl('http://api.roll.news.sina.com.cn/zt_list?channel=news&cat_1=gnxw&cat_2==gdxw1||=gatxw||=zs-pl||=mtjj&level==1||=2&show_ext=1&show_all=1&show_num=22&tag=1&format=json&page=1&_=1484453798220').then((b)=>{
  var str=b.toString();

  var data=JSON.parse(str).result.data;

  var i=0;

  _next();
  function _next(){
    function doNext(){
      i++;

      if(i==data.length){
        console.log('都完事');
      }else{
        _next();
      }
    }

    getSinaNews(data[i].url).then(()=>{
      console.log('成功', data[i].url);
      doNext();
    }, (err)=>{
      console.error('失败', err, data[i].url);
      doNext();
    });
  }
}, (err)=>{
  console.error(err);
});
