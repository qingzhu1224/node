const jsdom=require('jsdom').jsdom;
const common=require('../lib/common');

module.exports=function (str){
  const document=jsdom(str);

  //title
  var title=document.getElementById('artibodyTitle').innerHTML;

  //time
  var oTime=document.getElementById('navtimeSource');
  oTime.removeChild(oTime.children[0]);

  var time=common.cndate2time(oTime.innerHTML);

  //content
  var oBody=document.getElementById('artibody');
  for(var i=0;i<oBody.children.length;i++){
    if(/ad_\d+/.test(oBody.children[i].id)){
      oBody.removeChild(oBody.children[i]);
      i--;
    }
  }

  var content=oBody.innerHTML.replace(/\n|\\n|\t|\\t/g, '');

  //keyword
  var aA=document.querySelectorAll('.article-keywords a');
  var keyword=',';

  for(var i=0;i<aA.length;i++){
    keyword+=aA[i].innerHTML+',';
  }

  return {title, time, content, keyword};
};
