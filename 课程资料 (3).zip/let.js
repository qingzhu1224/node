for(var i=0;i<10;i++){
  let a=12;

}

console.log(a);
