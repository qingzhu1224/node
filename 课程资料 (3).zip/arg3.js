function aaa(...a){
  console.log('a是', a);
}


function show(a, b, ...args){
  aaa(...args);
}

show(12, 5, 99, 88, 55, 33);
