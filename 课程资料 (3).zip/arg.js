function show(a, b, ...args){
  console.log('a', a);        //12
  console.log('b', b);        //5
  console.log('args', args);  //99, 88, 55, 33
}

show(12, 5, 99, 88, 55, 33);
