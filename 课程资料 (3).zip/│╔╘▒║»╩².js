/*var json={
  aaa: 12,
  bbb: function (){
    console.log(this.aaa);
  }
};*/

var json={
  aaa: 12,
  bbb(){
    console.log(this.aaa);
  }
}

json.bbb();
