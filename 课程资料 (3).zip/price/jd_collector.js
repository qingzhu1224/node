const getUrl=require('./lib/get-url');
const jdParser=require('./parser/jd-parser');

getUrl('https://item.jd.com/10743155857.html').then((b)=>{
  var data=jdParser(b);

  console.log(data);
}, (err)=>{
  console.log('失败了');
  console.error(err);
});
