const gbk=require('gbk');
const jsdom=require('jsdom').jsdom;

module.exports=function (b){
  var document=jsdom(gbk.toString('utf-8', b));

  //name
  var name=document.querySelector('.sku-name').innerHTML;

  //price
  var price=document.querySelector('.price').innerHTML;

  //platform
  var platform='京东';

  //href
  var href='';

  //keyword
  var keyword=document.querySelector('meta[name=keywords]').content;;

  return {name, price, platform, href, keyword};
};
