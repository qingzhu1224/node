const koa=require('koa');
const static=require('koa-static');
const route=require('koa-route');

let server=new koa();
server.listen(8080);

server.use(route.get('/sendMsg', function *(){
  this.body='adfasdfasdf';
}));
