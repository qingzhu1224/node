const koa=require('koa');
const static=require('koa-static');
const mysql=require('koa-mysql');
const route=require('koa-route');

let db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170301'});

let server=new koa();
server.listen(8080);

/*
1.发送消息
/sendMsg?name=xxx&content=xxx
=>{ok: true, msg: xxx}
*/
server.use(route.get('/sendMsg', function *(){
  let name=this.query['name'];
  let content=this.query['content'];

  yield db.query(`
    INSERT INTO msg_table
    (name, content, time)
    VALUES('${name}', '${content}', ${Math.floor(new Date().getTime()/1000)})
  `);

  this.body={err: false};
}));

/*
2.接收消息    增量更新(全量更新)
/getMsg?last_id=xxx
[{name: xxx, content: xxx, time: 时间戳}, ...]
*/
server.use(route.get('/getMsg', function *(){
  let last_id=this.query['last_id']||'0';

  let data=yield db.query(`SELECT * FROM msg_table WHERE ID>${last_id}`);

  this.body=data;
}));

server.use(static('www'));

//10分钟检查一次
const common=require('./libs/common');

common.interval(function* (){
  let oDate=new Date();
  oDate.setDate(oDate.getDate()-3);

  let time=Math.floor(oDate.getTime()/1000);

  yield db.query(`DELETE FROM msg_table WHERE time<=${time}`);
}, 10*60*1000);
