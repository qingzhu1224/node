const io=require('socket.io');
const http=require('http');
const mysql=require('mysql');

let db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170301'});

let server=http.createServer((req, res)=>{});
server.listen(8080);







let wsServer=io.listen(server);

wsServer.on('connection', sock=>{
  sock.on('login', (user, pass)=>{
    db.query(`SELECT * FROM user_table WHERE username='${user}'`, (err, data)=>{
      console.log(err);

      if(err){
        sock.emit('login', {err: true, msg: '数据库错误'});
      }else if(data.length==0){
        sock.emit('login', {err: true, msg: '此用户不存在'});
      }else if(data[0].password!=pass){
        sock.emit('login', {err: true, msg: '密码错误'});
      }else{
        sock.emit('login', {err: false});
      }
    });
  });
});
