const http=require('http');
const io=require('socket.io');
const mysql=require('mysql');

let db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20170301'});

let server=http.createServer((req, res)=>{});
server.listen(8080);





let wsServer=io.listen(server);

let arr=[];

wsServer.on('connection', sock=>{
  arr.push(sock);

  db.query('SELECT * FROM msg_table', (err, data)=>{
    if(!err){
      sock.emit('old_msgs', data);
    }
  });

  sock.on('msg', (name, msg)=>{
    let time=Math.floor(new Date().getTime()/1000);

    db.query(`
      INSERT INTO msg_table
      (name, content, time)
      VALUES('${name}', '${msg}', ${time})
    `);

    arr.forEach(sock=>{
      sock.emit('msg', name, msg, time);
    });
  });
});
