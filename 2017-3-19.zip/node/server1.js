const io=require('socket.io');
const http=require('http');

let server=http.createServer((req, res)=>{});
server.listen(8080);

let wsServer=io.listen(server);

wsServer.on('connection', sock=>{
  sock.on('aaa', (num)=>{
    console.log('接收到了：'+num)
  });
});
