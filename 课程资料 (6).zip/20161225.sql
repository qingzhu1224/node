/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50703
Source Host           : localhost:3306
Source Database       : 20161225

Target Server Type    : MYSQL
Target Server Version : 50703
File Encoding         : 65001

Date: 2016-12-25 17:24:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for banner_table
-- ----------------------------
DROP TABLE IF EXISTS `banner_table`;
CREATE TABLE `banner_table` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL COMMENT '标题',
  `description` varchar(350) NOT NULL COMMENT '描述',
  `url` varchar(300) NOT NULL COMMENT '跳转地址',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of banner_table
-- ----------------------------
INSERT INTO `banner_table` VALUES ('1', '台媒:大陆年轻人渐推', '参考消息网12月25日报道台媒称，中国大陆20世纪50年代以来一直推行简体字，近年来茶艺课、书法课受到欢迎，还有些人会刻意写繁体字。有民众表示，这是对社会太追求物质发展后的反省。', 'http://news.163.com/16/1225/02/C93L3FNC0001875P.html');
INSERT INTO `banner_table` VALUES ('2', 'aaaaaa', 'dsfsdgjl;sdkgjwpoe irut4wp95up42 ptu3 4p5tu345t u3p4t5u34wt u34wt59u4t58uw40t58up9', 'http://a.com/');
INSERT INTO `banner_table` VALUES ('3', 'badfasdasdgfd', 'd;wertiwp459824t j34;ot6u 43ptjoir gtjp345t pu4wiotjg e4wpoutp4wo5ut p4wut5pw4oi5jgwpo', 'http://b.com');

-- ----------------------------
-- Table structure for blog_table
-- ----------------------------
DROP TABLE IF EXISTS `blog_table`;
CREATE TABLE `blog_table` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL COMMENT '标题',
  `pic_sm` varchar(300) NOT NULL COMMENT '小图地址',
  `pic_bg` varchar(300) NOT NULL COMMENT '大图地址',
  `post_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP COMMENT '提交时间',
  `author` varchar(32) NOT NULL COMMENT '作者的名字',
  `n_view` int(11) NOT NULL COMMENT '查看次数',
  `content` text NOT NULL COMMENT '文章内容',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of blog_table
-- ----------------------------

-- ----------------------------
-- Table structure for custom_evaluation_table
-- ----------------------------
DROP TABLE IF EXISTS `custom_evaluation_table`;
CREATE TABLE `custom_evaluation_table` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL COMMENT '标题',
  `description` varchar(350) NOT NULL COMMENT '描述',
  `url` varchar(300) NOT NULL COMMENT '头像地址',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of custom_evaluation_table
-- ----------------------------
INSERT INTO `custom_evaluation_table` VALUES ('1', '我觉得这网站好', '就是好，本来就好，真的好，就是那么好就是好，本来就好，真的好，就是那么好', 'images/c1.jpg');
INSERT INTO `custom_evaluation_table` VALUES ('2', '我也觉得好', '好，真好，特好，贼好，非常好，怎么那么好', 'images/c2.jpg');
INSERT INTO `custom_evaluation_table` VALUES ('3', '我也是觉得好', '好，真的，好，好的，很好的', 'images/c3.jpg');
