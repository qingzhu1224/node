const Koa=require('koa');
const static=require('koa-static');
const mysql=require('koa-mysql');
const Router=require('koa-router');
const body=require('koa-better-body');
const ejs=require('koa-ejs');
const session=require('koa-session');

//1.准备工作——创建、监听、post数据、模板引擎
let server=new Koa();
server.listen(5000);
server.use(body());

server.use(session({
  maxAge: 1200000
}, server));

ejs(server, {
  root: './template/',
  layout: false,
  viewExt: 'ejs',
  cache: false,
  debug: true
});

const db=mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456',
  database: '20170226',
  connectionLimit: 100
});

//2.后台管理
//i.统配  ->所有/admin/xxx    都检查
//ii.指定

{
  let r1=new Router();
  server.use(r1.routes());

  r1.get('/admin/*', function *(next){
    if(!this.session['adminID'] && this.url!='/admin/login/'){
      this.redirect('/admin/login/');
    }else{
      yield next;
    }
  });

  let r2=new Router();
  r2.prefix('/admin/');
  server.use(r2.routes());

  r2.get('/login', function *(){
    yield this.render('login');
  });
  r2.get('/index', function *(){
    yield this.render('index');
  });
}

//3.前台接口


//4.静态文件
server.use(static('./public_static', {
  maxage: 86400000,
  index: 'index.html'
}));
