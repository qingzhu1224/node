const Koa=require('koa');
const static=require('koa-static');
const mysql=require('koa-mysql');
const Router=require('koa-router');
const body=require('koa-better-body');
const ejs=require('koa-ejs');
const session=require('koa-session');
const common=require('./libs/common');

//1.准备工作——创建、监听、post数据、模板引擎
let server=new Koa();
server.listen(5000);
server.use(body());

{
  server.keys=['12','5','8','99','27'];
  server.use(session({
    maxAge: 60000
  }, server));
}

ejs(server, {
  root: './template/',
  layout: false,
  viewExt: 'ejs',
  cache: false,
  debug: true
});

const db=mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456',
  database: '20170226',
  connectionLimit: 100
});

//2.后台管理
//i.统配  ->所有/admin/xxx    都检查
//ii.指定

{
  let r1=new Router();
  server.use(r1.routes());

  //最高：login
  r1.get('/admin/login/', function *(){
    yield this.render('login', {err_msg: null});
  });
  r1.post('/admin/login/', function *(){
    let data=yield db.query(`SELECT * FROM admin_table WHERE username='${this.request.fields['user']}'`);

    if(data.length==0){
      yield this.render('login', {err_msg: '没有此用户'});
    }else{
      if(data[0].password!=common.md5(this.request.fields['pass'])){
        yield this.render('login', {err_msg: '用户名或密码有误'});
      }else{
        this.session['adminID']=data[0].ID;
        this.redirect('/admin/index');
      }
    }

    this.request.fields
  });

  //一般：检验是否登陆过
  function *checkAdminLogin(next){
    if(!this.session['adminID']){
      this.redirect('/admin/login/');
    }else{
      yield next;
    }
  }
  r1.get('/admin/*', checkAdminLogin);
  r1.post('/admin/*', checkAdminLogin);
  r1.delete('/admin/*', checkAdminLogin);
  r1.put('/admin/*', checkAdminLogin);

  //最低：
  let r2=new Router();
  r2.prefix('/admin/');
  server.use(r2.routes());

  r2.get('/hb', function *(){
    this.session['t']=new Date().getTime();
  });

  r2.get('/city', function *(){
    let citys=yield db.query(`SELECT * FROM city_table`);

    yield this.render('city', {citys, err_msg: null, city: '', capital: ''});
  });
  r2.post('/city', function *(){
    let citys=yield db.query(`SELECT * FROM city_table`);

    let city=this.request.fields['city'];
    let capital=this.request.fields['capital'];

    //1.校验
    if(!city){
      yield this.render('city', {citys, err_msg: '请填写城市名称', city, capital});
      return;
    }

    if(!capital){
      yield this.render('city', {citys, err_msg: '请填写城市首字母', city, capital});
      return;
    }

    //2.是否重复
    let data=yield db.query(`SELECT * FROM city_table WHERE city_name='${city}'`);

    if(data.length>0){
      yield this.render('city', {citys, err_msg: '此城市已存在', city, capital});
      return;
    }

    //3.插入
    yield db.query(`INSERT INTO city_table VALUES(0,'${city}','${capital}')`);

    //4.重新获取数据 & 渲染
    citys=yield db.query(`SELECT * FROM city_table`);
    yield this.render('city', {citys, err_msg: null, city: null, capital: null});
  });

  r2.get('/index', function *(){
    yield this.render('index');
  });
}

//3.前台接口


//4.静态文件
server.use(static('./public_static', {
  maxage: 86400000,
  index: 'index.html'
}));
