var session = require('koa-session');
var koa = require('koa');
var app = new koa();

let server=new koa();
server.listen(8080);

server.keys=['1','2','3','4'];
server.use(session({
  maxAge: 600000000
}, server));

server.use(function *(){
  if(!this.session.view){
    this.session.view=1;
  }else{
    this.session.view++;
  }

  this.body=this.session.view;
});
