const Koa=require('koa');
const Router=require('koa-router');

let server=new Koa();
server.listen(5000);

let r1=new Router();
let r2=new Router();


r1.get('/aaa', function *(){
  this.body='22222';
});
r1.get('/aaa', function *(){
  this.body='1111';
});

server.use(r1.routes());
