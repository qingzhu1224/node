const Koa=require('koa');
const Router=require('koa-router');

let server=new Koa();
server.listen(5000);

let r=new Router();

r.get('/user/*', function *(){
  this.body='ab53453454c';
});

server.use(r.routes());
