//async/await

//async =>*
//await =>yield

//async/awit跟generator功能一模一样；

function* show(){
  let a=yield 12;
  let b=yield 5;

  return a+b; //66+77
}

let gen=show();

let res1=gen.next(55);    //{value: 12, done: false}
console.log(res1);

let res2=gen.next(66);    //{value: 5, done: false}
console.log(res2);

let res3=gen.next(77);    //{value: 143, done: true}
console.log(res3);
