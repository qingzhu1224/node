const koa=require('koa');
const Router=require('koa-router');

let server=new koa();
server.listen(5000);

//1.new一个
let r1=new Router();

//2.规定一堆东西——方法、路径、参数
r1.get('/getUser', function *(){
  this.body='用户';
});

r1.get('/getNews', function *(){
  this.body='新闻';
});

//3.加到koa上面去
server.use(r1.routes());
