const koa=require('koa');
const Router=require('koa-router');

let server=new koa();
server.listen(5000);

//1.new一个
let r1=new Router();

let users={
  '19': {name: '张三', company: '百度'},
  '22': {name: '李四', company: '新浪'},
  '35': {name: '王五', company: '优酷'}
};

//2.规定一堆东西——方法、路径、参数
//urlencoding    'http://xxxx/getUser?id=xxx'
//伪静态         'http://xxxx/getUser/xxxx/'
r1.get('/getUser', function *(){
  let userData=users[this.query['id']];

  if(userData){
    this.body={ok: true, data: userData};
  }else{
    this.body={ok: false, data: null};
  }
});


//3.加到koa上面去
server.use(r1.routes());
