const koa=require('koa');
const route=require('koa-route');

let server=new koa();
server.listen(5000);

server.use(route.get('/getUser', function *(){
  this.body='用户';
}));

server.use(route.get('/getNews', function *(){
  this.body='新闻';
}));
