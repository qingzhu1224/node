const jade=require('jade');

//jade.render("模板字符串", {参数});

console.log(jade.renderFile('./views/6.jade', {
  pretty: true,
  arr: [12,2,8,5,33,79]
}));
