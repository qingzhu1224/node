const express=require('express');
const static=require('express-static');
const bodyParser=require('body-parser');
const multerLib=require('multer');
const multer=multerLib({dest: './www/upload'});
const cookieParser=require('cookie-parser');
const cookieSession=require('cookie-session');
const moveUpload=require('./libs/move_upload.js');

//1.创建服务器
var server=express();
server.listen(8080);

//2.解析数据
server.use(bodyParser.urlencoded());
server.use(multer.any());
server.use(moveUpload());
server.use(cookieParser());
server.use(cookieSession({
  name: 'sess',
  keys: [...],
  maxAge: 20*60*1000
}));

//3.接收用户请求
server.get
server.post
server.use

//express-route
