const express=require('express');
const static=require('express-static');

var server=express();
server.listen(8080);

server.get('/', (req, res)=>{
  res.send({a: 12, b: 5, c: 33});
  res.end();
});
