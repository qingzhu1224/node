const express=require('express');
const static=require('express-static');

var server=express();
server.listen(8080);

server.get('/', (req, res)=>{
  console.log(req.query);

  res.end('sdfsdf');
});
