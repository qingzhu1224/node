const express=require('express');
const cookieParser=require('cookie-parser');

var server=express();
server.listen(8080);

//解析cookie
server.use(cookieParser());

//使用cookie
server.get('/', (req, res)=>{
  console.log(req.cookies);

  res.cookie('b', '6.6', {path: '/', maxAge: 365*24*3600*1000});

  //....

  res.cookie('gender', 'male');

  res.end('aaa');
});
