const express=require('express');
const static=require('express-static');
const bodyParser=require('body-parser');

var server=express();
server.listen(8080);

server.get('/', (req, res, next)=>{
  console.log('a');

  next();
});
server.get('/', (req, res, next)=>{
  console.log('b');

  res.send('abc');
  res.end();
});
