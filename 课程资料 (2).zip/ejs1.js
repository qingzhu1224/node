const ejs=require('ejs');

ejs.renderFile('./views/1.ejs', {
  name: 'blue',
  age: 18
}, (err, data)=>{
  if(err)
    console.log('渲染失败');
  else
    console.log(data);
});
