const express=require('express');
const static=require('express-static');
const bodyParser=require('body-parser');
const multer=require('multer')({dest: './www/upload'});
const cookieParser=require('cookie-parser');
const cookieSession=require('cookie-session');

var server=express();
server.listen(8080);

//解析各种数据
//get      直接有
//普通post
server.use(bodyParser.urlencoded());
//文件post
server.use(multer.any());
//cookie
server.use(cookieParser());
//session
var arr=[];
for(var i=0;i<100000;i++){
  arr[i]='keys_'+Math.random();
}
server.use(cookieSession({
  name: 'sessid',
  maxAge: 20*60*1000,
  keys: arr
}));
//处理upload里面的文件名
server.use(require('./libs/move_upload.js'));

//正式处理数据、处理用户请求
server.use('/', (req, res)=>{
  console.log(req.files);

  res.end('abc');
});
