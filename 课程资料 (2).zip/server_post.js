const express=require('express');
const static=require('express-static');
const bodyParser=require('body-parser');

var server=express();
server.listen(8080);

server.use(bodyParser.urlencoded());

server.post('/', (req, res)=>{
  console.log(req.body);

  res.end('sdfsdf');
});
