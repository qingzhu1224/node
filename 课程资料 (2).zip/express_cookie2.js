const express=require('express');
const cookieParser=require('cookie-parser');

var server=express();
server.listen(8080);

//解析cookie
server.use(cookieParser());

//使用cookie
server.get('/', (req, res)=>{
  console.log(req.cookies);

  if(req.cookies['count']){
    req.cookies['count']++;
  }else{
    req.cookies['count']=1;
  }

  res.cookie('count', req.cookies['count']);

  if(req.cookies['count']%100==0){
    console.log('可以抽奖了')
  }


  res.end('aaa');
});
