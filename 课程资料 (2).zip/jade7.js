const jade=require('jade');

//jade.render("模板字符串", {参数});

console.log(jade.renderFile('./views/7.jade', {
  pretty: true,
  score: 79
}));
