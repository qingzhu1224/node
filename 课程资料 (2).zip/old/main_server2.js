const http=require('http');
const zlib=require('zlib');
const fs=require('fs');

http.createServer((req, res)=>{
  var gz=zlib.createGzip();
  var rs=fs.createReadStream('./www'+req.url);

  res.setHeader('content-encoding', 'gzip');

  rs.pipe(gz);
  gz.pipe(res);

  rs.on('error', (err)=>{
    res.writeHeader(404);
    res.write('您的东西没找到');
    res.end();
  });


  /*
  fs.readFile('./www'+req.url, (err, data)=>{
    if(err){
      res.writeHeader(404);
      res.write('您请求的东西，没找着');
    }else
      res.write(data);

    res.end();
  });
  */
}).listen(8080);
