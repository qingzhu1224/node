const Events=require('events').EventEmitter;

var ev=new Events();

ev.on('error', (str)=>{
  console.log(str);
});

ev.emit('error', '反正错了');
