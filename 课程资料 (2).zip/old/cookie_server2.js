const http=require('http');
const zlib=require('zlib');
const fs=require('fs');
const crypto=require('crypto');

function md5(str){
  var obj=crypto.createHash('md5');
  obj.update(str);
  return obj.digest('hex');
}

var secrt='werfs353fwefFDSFdfwerLDJlo9u453u4rlfhldsfghsdljgh;43t?DFJSK:Lj/sdfj>JKDF:SDK:FLJ;ojsef/DJKFDSJKLF:水电费文';

http.createServer((req, res)=>{
  //发送cookie
  var value='blue';
  res.setHeader('set-cookie', 'user='+value+':'+md5(value+secrt));

  //接收cookie
  var cookie=req.headers['cookie'];
  if(cookie){
    var new_value=cookie.split('=')[1];

    var arr=new_value.split(':');

    if(arr[1]==md5(arr[0]+secrt)){
      console.log('没改过', arr[0]);
    }else{
      console.log('改过');
    }
  }





  res.end('dsfsdf');
}).listen(8080);
