const http=require('http');
const zlib=require('zlib');
const fs=require('fs');

http.createServer((req, res)=>{
  //console.log(req.headers['cookie']);
  var oDate=new Date();
  oDate.setDate(oDate.getDate()+5);
  res.setHeader('set-cookie', [
    'a=12; path=/; expires='+oDate.toGMTString(),
    'b=5',
    'c=99'
  ]);

  res.end('advasdfasdfasd');
}).listen(8080);
