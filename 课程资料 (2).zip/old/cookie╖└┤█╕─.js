const crypto=require('crypto');

function md5(str){
  var obj=crypto.createHash('md5');
  obj.update(str);
  return obj.digest('hex');
}

var old_value='123456';
var new_value=old_value+':'+md5(old_value+'wesarsd35fsd456');

//把new_value传给用户



var arr=new_value.split(':');

arr[0]='987654';
arr[1]=md5(arr[0]);

new_value=arr[0]+':'+arr[1];




//.......

//还给我
var cookie=new_value;
var arr=cookie.split(':');
//arr[0]->value
//arr[1]->签名

if(md5(arr[0]+'wersd35fsd456')==arr[1]){
  console.log('没改过,值就是：'+arr[0]);
}else{
  console.log('改过');
}
