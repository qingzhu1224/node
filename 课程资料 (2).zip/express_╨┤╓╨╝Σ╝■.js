const express=require('express');
const myBodyParser=require('./libs/my_body_parser');

var server=express();
server.listen(8080);

server.use(myBodyParser);

server.post('/', function (req, res){
  console.log(req.body);
  res.end('abc');
});
