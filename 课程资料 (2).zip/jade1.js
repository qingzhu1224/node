const jade=require('jade');

//jade.render("模板字符串", {参数});

console.log(jade.renderFile('./views/1.jade', {
  pretty: true,
  json1: {'z-index': 2, float: 'left', clear: 'both'}
}));
