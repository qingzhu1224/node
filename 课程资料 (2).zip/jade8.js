const jade=require('jade');

//jade.render("模板字符串", {参数});

console.log(jade.renderFile('./views/8.jade', {
  pretty: true,
  gender: 'male'
}));
