const express=require('express');
const multer=require('multer')({dest: './www/upload'});
const pathLib=require('path');
const fs=require('fs');

var server=express();
server.listen(8080);


//用multer接收文件
server.use(multer.any());

//处理文件
server.post('/upload', (req, res, next)=>{
  for(var i=0;i<req.files.length;i++){
    var file=req.files[i];

    //'2.gif'
    var ext=pathLib.parse(file.originalname).ext;
    var dir=pathLib.parse(file.path).dir;

    //'www\\upload\\8dd9b360eb694d219a9d64c1718a9e33'
    var newPath=dir+'/'+new Date().getTime()+Math.random()+ext;
    //'www\\upload\\8dd9b360eb694d219a9d64c1718a9e33.gif'

    fs.rename(file.path, newPath, (err)=>{});
  }

  res.end('文件上传完成');
});
