const express=require('express');
const cookieSession=require('cookie-session');

var server=express();
server.listen(8080);

var arr=[];
for(var i=0;i<100000;i++){
  arr[i]='key_'+Math.random();
}

server.use(cookieSession({
  name: 'zns_sessid',
  maxAge: 20*60*1000,
  keys: arr
}));
server.get('/', (req, res)=>{
  console.log(req.session);

  if(req.session['count']){
    req.session['count']++;
  }else{
    req.session['count']=1;
  }

  console.log(req.headers['cookie']);

  res.end('abc');
});
