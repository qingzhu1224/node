const pathLib=require('path');

var str='/usr/home/aaa/1.jpg';

var obj=pathLib.parse(str);

console.log(obj);
