const ejs=require('ejs');
const fs=require('fs');

//ejs.delimiter='#';

ejs.renderFile('./views/2.ejs', {
  arr: [
    {name: '小红', gender: 'female', age: 8, comment: '<strong>aaa</strong>bbb'},
    {name: '小明', gender: 'male', age: 6, comment: '<strong>aaa</strong>bbb'},
    {name: '张三', gender: 'male', age: 28, comment: '<strong>aaa</strong>bbb'},
    {name: '李四', gender: 'male', age: 25, comment: '<strong>aaa</strong>bbb'}
  ]
}, (err, data)=>{
  if(err)
    console.log('渲染失败');
  else
    fs.writeFile('./build/user_table.html', data, (err)=>{
      if(err)
        console.log('写入失败');
      else
        console.log('写入成功');
    });
});
