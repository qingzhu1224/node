const express=require('express');
const static=require('express-static');

//1.创建服务
var server=express();
//2.监听
server.listen(8080);

//3.处理请求
server.use(static('./www'));
