const jade=require('jade');

//jade.render("模板字符串", {参数});

console.log(jade.renderFile('./views/9.jade', {
  pretty: true,
  str: '<div><h2>ssss</h2><p>xbxcvbxcxcncvbn</p></div>'
}));
