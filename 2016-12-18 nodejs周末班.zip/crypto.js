const crypto=require('crypto');

var obj=crypto.createHash('md5');

//obj.update('abcdef');
obj.update('a');
obj.update('bc');
obj.update('def');

var str=obj.digest('hex');

console.log(str);
