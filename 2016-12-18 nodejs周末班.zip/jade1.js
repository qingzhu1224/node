const jade=require('jade');

var str=jade.renderFile('./template/1.jade', {
  pretty: true,
  datas: [{name: 'blue', pass: '123456'},{name: 'aaa', pass: '987654'},{name: 'bbb', pass: '1111111'}]
});

console.log(str);
