const mysql=require('mysql');

//1.连接到数据库
//createConnection(参数)
var db=mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  port: 3306,
  database: '20161218'
});

//2.查询
//query(SQL, 回调)

var sql="SELECT * FROM `user_table`";

db.query(sql, (err, data)=>{
  if(err)
    console.log('出错了', err);
  else
    console.log('成功了', JSON.stringify(data));
});
