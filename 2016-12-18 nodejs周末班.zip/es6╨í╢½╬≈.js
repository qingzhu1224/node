var a=12;
var b=5;
var c=55;

//var json={a: a, b: b, c: c};
var json={a, b, c, e: 99};

console.log(json);
