//for(var i=0;i<arr.length;i++)
//for(var key in json)

//for on循环

var json={a: 12, b: 5, c: 99};

for(var i of json.keys()){
  console.log(i);
}
