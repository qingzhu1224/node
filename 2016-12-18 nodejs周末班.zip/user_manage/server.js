const express=require('express');
const static=require('express-static');
const ejs=require('ejs');
const mysql=require('mysql');

var server=express();
server.listen(8080);

//连接数据库
var db=mysql.createPool({
  host: 'localhost', user: 'root', password: '', database: '20161218'
});

//学历转换json
var GENDER={
  0: '男',
  1: '女',
  2: '保密',
  3: '秘密'
}
var DEGREES={
  0: '未填写',
  1: '幼儿园',
  2: '小学',
  3: '中学',
  4: '大专',
  5: '本科',
  6: '研究生',
  7: '博士生',
  8: '院士',
  100: '其他'
};

//各种增删改操作
server.get('/index', (req, res, next)=>{
  //完成用户指定的操作
  switch(req.query.act){
    case 'del':
      var sql=`DELETE FROM user_table WHERE ID=${req.query.id}`;
      db.query(sql, (err, data)=>{
        if(err){
          console.log(err);
          res.status(500).send('database error').end();
        }else{
          //跳转到"/index"
          res.status(302).header('location', '/index').end();
        }
      });
      break;
    case 'add':
      //TODO：数据校验
      var sql=`INSERT INTO user_table \
      (username, password, gender, degree)
      VALUES('${req.query.username}','${req.query.password}','${req.query.gender}','${req.query.degree}')
      `;
      db.query(sql, (err, data)=>{
        if(err){
          console.log(err);
          res.status(500).send('database error').end();
        }else{
          res.status(302).header('location', '/index').end();
        }
      });
      break;
    default:    //没给act或act不知道是个什么
      next();   //只显示，不做什么操作
      break;
  }
});

//显示页面的数据
server.get('/index', (req, res)=>{
  if(req.query.keyword){
    var sql=`SELECT * FROM user_table WHERE username LIKE '%${req.query.keyword}%'`;
  }else{
    var sql=`SELECT * FROM user_table`;
  }

  console.log(sql);
  db.query(sql, (err, users)=>{
    if(err){
      console.log(err);
      res.status(500).send('database error').end();
    }else{
      ejs.renderFile(
        './template/index.ejs',
        {users, DEGREES, GENDER, keyword: req.query.keyword},
        (err, data)=>{
        if(err){
          console.log(err);
          res.status(500).send('server error').end();
        }else{
          res.send(data).end();
        }
      });
    }
  });
})
