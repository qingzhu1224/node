const mysql=require('mysql');

//1.连接到数据库
//createConnection(参数)
var db=mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  port: 3306,
  database: '20161218'
});

//2.查询
//query(SQL, 回调)

var sql=
"INSERT INTO `user_table` \
(`username`,`password`,`gender`, `degree`) \
VALUES('blue3','abcdef',0,1)";

db.query(sql, (err, data)=>{
  if(err)
    console.log('出错了', err);
  else
    console.log('成功了', data);
});
