const ejs=require('ejs');

ejs.renderFile('./template/1.ejs', {
  logined: false
}, (err, data)=>{
  if(err)
    console.log('错了', err);
  else
    console.log(data);
});
