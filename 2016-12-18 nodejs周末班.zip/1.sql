SELECT 什么 FROM 表
  SELECT * FROM `20161218`.`user_table`;

INSERT INTO 表 (字段名) VALUES(值)
  INSERT INTO `user_table`
  (`ID`,`username`,`password`,`gender`,`degree`)
  VALUES(0,'blue2','123456','0','1');

  INSERT INTO `user_table`
  (`username`,`password`,`gender`,`degree`)
  VALUES('blue2','123456','0','1');

DELETE FROM 表
  DELETE FROM `user_table`;

UPDATE 表 SET 字段=值,字段=值,...
  UPDATE `user_table` SET `password`='888888'

WHERE子句
  SELECT * FROM `user_table`;
  =>返回所有数据
  SELECT * FROM `user_table` WHERE `ID`=1

  DELETE FROM `user_table`
  =>删除全部数据
  DELETE FROM `user_table` WHERE `ID`=5
