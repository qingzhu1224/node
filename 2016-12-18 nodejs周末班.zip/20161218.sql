-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2016-12-18 10:18:01
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `20161218`
--

-- --------------------------------------------------------

--
-- 表的结构 `student_table`
--

CREATE TABLE IF NOT EXISTS `student_table` (
  `name` varchar(30) NOT NULL,
  `class` int(11) NOT NULL,
  `chinese` int(11) NOT NULL,
  `math` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `student_table`
--

INSERT INTO `student_table` (`name`, `class`, `chinese`, `math`) VALUES
('小强', 1, 25, 87),
('小明', 1, 87, 55),
('小刚', 2, 58, 47),
('aaa', 1, 54, 87),
('bbb', 2, 57, 87),
('ccc', 3, 78, 98),
('ddd', 2, 57, 87);

-- --------------------------------------------------------

--
-- 表的结构 `test_table`
--

CREATE TABLE IF NOT EXISTS `test_table` (
  `name` varchar(30) NOT NULL,
  `age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `test_table`
--

INSERT INTO `test_table` (`name`, `age`) VALUES
('张三', 18),
('小明', 8),
('张大爷', 98),
('小强', 68);

-- --------------------------------------------------------

--
-- 表的结构 `user_buy_table`
--

CREATE TABLE IF NOT EXISTS `user_buy_table` (
  `user_id` int(11) NOT NULL,
  `price` float NOT NULL,
  `number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user_buy_table`
--

INSERT INTO `user_buy_table` (`user_id`, `price`, `number`) VALUES
(1, 58, 2),
(1, 98, 1),
(2, 9.9, 3),
(3, 10.5, 20),
(1, 98.3, 30),
(2, 99.8, 2),
(3, 87, 5),
(5, 2800, 50);

-- --------------------------------------------------------

--
-- 表的结构 `user_table`
--

CREATE TABLE IF NOT EXISTS `user_table` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL COMMENT '用户名',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `gender` tinyint(1) NOT NULL COMMENT '性别，0-男/1-女',
  `degree` tinyint(3) unsigned NOT NULL COMMENT '学历',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `username` (`username`),
  FULLTEXT KEY `password` (`password`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='用户表' AUTO_INCREMENT=47 ;

--
-- 转存表中的数据 `user_table`
--

INSERT INTO `user_table` (`ID`, `username`, `password`, `gender`, `degree`) VALUES
(1, 'blue', '888888', 0, 1),
(9, '吴世勋', '654abc', 1, 5),
(18, 'ewrwqer', 'sddgsdfg', 0, 0),
(19, 'erterw', 'sdfgsfdh', 0, 0),
(20, 'dfghdfg', 'dfghdfgh', 0, 0),
(21, 'dfghdfhvcb', 'ge', 0, 0),
(22, '234', '234', 0, 0),
(23, '3erg', 'sdfgsdfg', 0, 0),
(30, 'xcbcvb', 'cvbxcvb', 0, 0),
(37, 'aaa', '123456', 0, 2),
(40, '张三', '123456', 0, 3),
(41, 'asdfads', 'sdfwef', 0, 0),
(42, 'ewrwe', 'asdgdsfg', 0, 0),
(43, 'dsfgsdfg', 'sdfgsdfg', 0, 0),
(44, 'rtet', 'etyrty', 0, 0),
(45, 'hfh', 'rtyrty', 0, 0),
(46, '5t45', 'tryrtytr', 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
