const znsAdd=require('zns-add');

console.log(znsAdd.add(12, 88));
