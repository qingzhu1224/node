var oDate=new Date();

console.log(oDate.getFullYear());
