var re=/\d+/g;
var str="asdf3232342 34 34rr433t rt45t45 ";

console.log(str.match(re));
