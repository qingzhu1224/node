const querystring=require('querystring');

var obj=querystring.parse("a=12&b=5&user=blue");

console.log(obj);
