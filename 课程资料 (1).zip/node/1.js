console.log(12);
