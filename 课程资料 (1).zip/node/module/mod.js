//mod.js  模块

//module    模块
//exports   导出、输出
//require   请求、引入

/*
exports.a=12;
exports.b=5;
exports.c=3;
*/

module.exports=function (){
  console.log(12);
};
