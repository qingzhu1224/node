//使用模块
const mod=require('./mod');

mod();
