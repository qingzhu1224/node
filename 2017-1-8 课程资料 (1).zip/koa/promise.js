const mysql=require('mysql');

var p=new Promise((resolve, reject)=>{
  var db=mysql.createPool({});

  db.query('xxxx', (err, data)=>{
    if(err)
      reject(err);
    else
      resolve(data);
  });
});

p.then((data)=>{
  console.log('成功');
}, (err)=>{
  console.log('有错');
});
