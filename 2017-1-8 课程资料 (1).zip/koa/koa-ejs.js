const koa=require('koa');
const ejs=require('koa-ejs');

var server=koa();
server.listen(8080);

//配置模板
ejs(server, {
  root: './views',
  viewExt: 'ejs',
  cache:false,
  debug:true
});

server.use(function *(){
  yield this.render('1', {title: '我是标题', name: 'blue', layout: '1'});
});
