const server=require('koa')();
server.listen(8080);
const db=require('koa-mysql').createPool({host: 'localhost', user: 'root', password: '123456', database: '20161226'});
const route=require('koa-route');
const static=require('koa-static');

server.use(route.get('/getTotalSales', function* (){
  var sql='SELECT name,SUM(price) AS total FROM sales_table GROUP BY name ORDER BY total DESC';

  this.body=yield db.query(sql);
}));

server.use(route.get('/getStudentScore', function* (){
  var sql=`SELECT * FROM student_table WHERE name='${this.query.name}'`;

  this.body=yield db.query(sql);
}));

server.use(static('./www'));
