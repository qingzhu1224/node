const koa=require('koa');
const session=require('koa-session');

var server=koa();
server.listen(8080);

server.keys=['111', '222', '333', '444'];
server.use(session(server));

server.use(function*(){
  this.body='abc';

  if(!this.session.count){
    this.session.count=1;
  }else{
    this.session.count++;
  }

  console.log(`这是第${this.session.count}次访问`);
});
