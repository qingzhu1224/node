function* show(){
  console.log('step#1');
  var a=yield 12;
  console.log(a);
  console.log('step#2');
}

var gen=show();

var res=gen.next(5);   //res=>{value: 12, done: false}
gen.next();
