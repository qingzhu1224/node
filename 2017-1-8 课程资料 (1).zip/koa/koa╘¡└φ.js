const mysql=require('mysql');
const db=mysql.createPool({host: 'localhost', user: 'root', password: '123456', database: '20161226'});

function query(sql){
  return new Promise((resolve, reject)=>{
    db.query(sql, (err, data)=>{
      if(err){
        reject(err);
      }else{
        resolve(data);
      }
    });
  });
}

function koz(genFn){
  var gen=genFn();

  var last_data=null;
  _next();
  function _next(){
    var obj=gen.next(last_data);

    if(!obj.done){  //没结束
      if(obj.value instanceof Promise){
        obj.value.then((data)=>{
          last_data=data;
          _next();
        }, (err)=>{
          throw err;
        });
      }else{
        throw new Error('必须是Promise，你懂不');
      }
    }
  }
}

koz(function *(){
  var sales=yield query('SELECT * FROM sales_table');
  var stu=yield query('SELECT * FROM student_table');

  console.log('=====销售=====');
  console.log(sales);

  console.log('=====学生=====');
  console.log(stu);
});
