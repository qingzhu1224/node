const koa=require('koa');

var server=koa();
server.listen(8080);

server.use(function *(){
  this.body=this.query;
});
