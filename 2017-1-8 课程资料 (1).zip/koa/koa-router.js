const koa=require('koa');
const route=require('koa-route');

const server=koa();
server.listen(8080);

server.use(route.get('/', function *(){
  this.body='首页';
}));
server.use(route.get('/a.html', function *(){
  this.body='abc';
}));
