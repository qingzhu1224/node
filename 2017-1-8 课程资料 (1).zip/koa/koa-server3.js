const koa=require('koa');
const body=require('koa-better-body');

var server=koa();
server.listen(8080);

server.use(body());

server.use(function *(){
  //this.request.fields     //域
  //this.request.body       //普通urlencoded数据
  //this.request.files      //文件信息

  console.log('=======fields=======');
  console.log(this.request.fields);

  console.log('=======body=======');
  console.log(this.request.body);

  console.log('=======files=======');
  console.log(this.request.files);

  this.body='abc';
});
