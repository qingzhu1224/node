const koa=require('koa');
const bodyParser=require('koa-body-parser');

var server=koa();
server.listen(8080);

server.use(bodyParser());

server.use(function *(){
  //POST数据
  this.body=this.request.body;
});
