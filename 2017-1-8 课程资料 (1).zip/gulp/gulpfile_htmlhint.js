const gulp=require('gulp');
const htmlHint=require('gulp-htmlhint');
const pump=require('pump');

gulp.task('default', function (cb){
  pump([
    gulp.src('./html/*'),
    htmlHint({
      'alt-require': true,
      'doctype-html5': true
    }),
    htmlHint.reporter()
  ], cb);
});
