const gulp=require('gulp');
const beautify=require('gulp-beautify');
const pump=require('pump');

gulp.task('default', function (cb){
  pump([
    gulp.src('./js/**/*'),
    beautify(),
    gulp.dest('./build/')
  ], cb);
});
