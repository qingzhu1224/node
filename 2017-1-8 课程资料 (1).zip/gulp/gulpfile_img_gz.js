const gulp=require('gulp');
const gzip=require('gulp-gzip');
const pump=require('pump');

//1.所有.js文件整合成一个大的
//2.压缩-uglify

gulp.task('default', function (cb){
  pump([
    gulp.src('./image/**/*'),
    gzip({extension: 'gz'}),
    gulp.dest('./build_img/'),
  ], cb);
});
