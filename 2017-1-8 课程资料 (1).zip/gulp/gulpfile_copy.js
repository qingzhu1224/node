const gulp=require('gulp');
const copy=require('gulp-copy');
const pump=require('pump');

gulp.task('default', function (cb){
  pump([
    gulp.src('./js/**/*'),
    copy('./build/', {prefix: 1})
  ], cb);
});
