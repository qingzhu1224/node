alert('abcc');

var a=12;

function show(){
  alert('bbb');
}
