const gulp=require('gulp');
const htmlmin=require('gulp-htmlmin');
const uglify=require('gulp-uglify');
const pump=require('pump');

gulp.task('minjs', function (cb){
  pump([
    gulp.src('./js/*'),
    uglify(),
    gulp.dest('./build/js/')
  ], cb);
});

gulp.task('minhtml', function (cb){
  pump([
    gulp.src('./html/*'),
    htmlmin({
      collapseWhitespace: true,
      minifyJS: true,
      minifyURLs: true,
      removeComments: true,
      removeEmptyElements: true,
      useShortDoctype: true,
      minifyCSS: true
    }),
    gulp.dest('./build/html/')
  ], cb);
});
