const gulp=require('gulp');
const concat=require('gulp-concat');
const uglify=require('gulp-uglify');
const gzip=require('gulp-gzip');
const pump=require('pump');

//1.所有.js文件整合成一个大的
//2.压缩-uglify

//任务1
gulp.task('concat', function (cb){
  pump([
    gulp.src('./js/**/*'),
    concat('zns.js'),
    gulp.dest('./build/')
  ], cb);
});

//任务2
gulp.task('uglify', (cb)=>{
  pump([
    gulp.src('./build/zns.js'),
    uglify(),
    gulp.dest('./zns.min.js')
  ], cb);
});

//任务3
gulp.task('gzip', (cb)=>{
  pump([
    gulp.src('./build/zns.min.js'),
    gzip({extension: 'zip'}),
    gulp.dest('./')
  ], cb);
});
