window.onload=function (){
  var oDiv=document.getElementById('div1');

  alert(getStyle(oDiv, 'width'));
};
