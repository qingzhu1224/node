const gulp=require('gulp');
const jshint=require('gulp-jshint');
const pump=require('pump');

gulp.task('default', function (cb){
  pump([
    gulp.src('./js/*'),
    jshint(),
    jshint.reporter()
  ], cb);
});
