const gulp=require('gulp');
const csslint=require('gulp-csslint');
const pump=require('pump');

gulp.task('default', function (cb){
  pump([
    gulp.src('./style/*'),
    csslint(),
    csslint.formatter()
  ], cb);
});
