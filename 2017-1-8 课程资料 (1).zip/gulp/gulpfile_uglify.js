const gulp=require('gulp');
const uglify=require('gulp-uglify');
const pump=require('pump');

//名字, 函数
gulp.task('default', function (cb){
  pump([
    gulp.src('./js/*.js'),
    uglify({output: {
      beautify: false,
      comments: true
    }}),
    gulp.dest('./build')
  ], cb);
});
