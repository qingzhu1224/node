const fs=require('fs');
const zlib=require('zlib');
const pump=require('pump');

pump([
  fs.createReadStream('1.js'),
  zlib.createGzip(),
  fs.createWriteStream('1.js.gz')
], (err)=>{

});
