const gulp=require('gulp');
const htmlmin=require('gulp-htmlmin');
const pump=require('pump');

gulp.task('default', function (cb){
  pump([
    gulp.src('./html/*'),
    htmlmin({
      collapseWhitespace: true,
      minifyJS: true,
      minifyURLs: true,
      removeComments: true,
      removeEmptyElements: true,
      useShortDoctype: true,
      minifyCSS: true
    }),
    gulp.dest('./build/')
  ]);
});
