const gulp=require('gulp');
const concat=require('gulp-concat');
const pump=require('pump');

gulp.task('default', function (cb){
  pump([
    gulp.src('./js/**/*'),
    concat('main.js'),
    gulp.dest('./build/')
  ], cb);
});
